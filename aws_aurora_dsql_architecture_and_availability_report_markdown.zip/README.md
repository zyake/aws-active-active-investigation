# Report files

Open aws_aurora_dsql_architecture_and_availability_report.md in a Markdown viewer. Keep the aws_aurora_dsql_architecture_and_availability_report_assets folder alongside it. The report includes expanded regional routing and RCA investigations, 46 diagrams, and source links. Original page references identify the earlier PDF and Word edition. Source links require internet access.
